import "./styles.css";
import Steps from "./Steps/Steps";

export default function App() {
  return (
    <div className="App">
      <Steps></Steps>
    </div>
  );
}
