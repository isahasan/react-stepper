import React, { useState } from "react";
import {
  Button,
  FormControl,
  FormLabel,
  Input,
  InputLabel,
  Grid
} from "@material-ui/core";
// import { AutoCompletePlaces } from "./AutoCompletePlaces";

const AddressForm = (props) => {
  const { autoPopulateData } = props;
  let add = [];
  let bed = [];
  let bath = [];
  let desc = [];
  let disable;
  if (autoPopulateData && autoPopulateData["1"]) {
    add = autoPopulateData["1"].data[0];
    bed = autoPopulateData["1"].data[1];
    bath = autoPopulateData["1"].data[2];
    desc = autoPopulateData["1"].data[3];
    disable = false;
  } else {
    disable = true;
  }

  const [address, setAddress] = useState(add);
  const [bedroom, setBedroom] = useState(bed);
  const [bathroom, setBathroom] = useState(bath);
  const [propertyDesc, setPropertyDesc] = useState(desc);
  const [disabled, isDisabled] = useState(disable);

  const handleAddressForm = () => {
    console.log(
      address,
      bedroom,
      bathroom,
      propertyDesc,
      "Address Form Submit"
    );
    props.handleNext();
  };

  const handleDisable = () => {
    if (address.length && bedroom.length && bathroom.length) {
      isDisabled(false);
    } else {
      isDisabled(true);
    }
  };
  const changeAddress = (e) => {
    setAddress(e.target.value);
    handleDisable();
  };
  const changeBedroom = (e) => {
    setBedroom(e.target.value);
    handleDisable();
  };
  const changeBathroom = (e) => {
    setBathroom(e.target.value);
    handleDisable();
  };
  const changePropertyDesc = (e) => {
    setPropertyDesc(e.target.value);
    handleDisable();
  };

  return (
    <React.Fragment>
      <form>
        <FormLabel>Address Form</FormLabel>
        <Grid container direction="row" justify="center" alignItems="center">
          <FormControl>
            <InputLabel htmlFor="address">Address</InputLabel>
            <Input
              id="address"
              name="address"
              type="text"
              defaultValue={address}
              onChange={changeAddress}
              fullWidth
            />
            {/* <AutoCompletePlaces /> */}
          </FormControl>
        </Grid>
        <Grid container direction="row" justify="center" alignItems="center">
          <FormControl>
            <InputLabel htmlFor="bedroom">Bedroom</InputLabel>
            <Input
              id="bedroom"
              name="bedroom"
              type="tel"
              fullWidth
              defaultValue={bedroom}
              onChange={changeBedroom}
              required
              inputProps={{ maxLength: 10 }}
            />
          </FormControl>
        </Grid>
        <Grid container direction="row" justify="center" alignItems="center">
          <FormControl>
            <InputLabel htmlFor="bathroom">Bathroom</InputLabel>
            <Input
              id="bathroom"
              name="bathroom"
              type="tel"
              fullWidth
              defaultValue={bathroom}
              onChange={changeBathroom}
              required
              inputProps={{ maxLength: 5 }}
            />
          </FormControl>
        </Grid>
        <Grid container direction="row" justify="center" alignItems="center">
          <FormControl>
            <InputLabel htmlFor="propertyDesc">
              Description of Property
            </InputLabel>
            <Input
              id="propertyDesc"
              name="propertyDesc"
              type="text"
              defaultValue={propertyDesc}
              onChange={changePropertyDesc}
              onClick={changePropertyDesc}
              multiline
              fullWidth
            />
          </FormControl>
        </Grid>
        <Grid container direction="row" justify="center" alignItems="center">
          <FormControl>
            <Button
              variant="contained"
              color="primary"
              onClick={handleAddressForm}
              style={{ margin: 10 }}
              disabled={disabled}
            >
              Submit
            </Button>
          </FormControl>
        </Grid>
      </form>
    </React.Fragment>
  );
};

export default AddressForm;
